﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praksa2022
{
    public class WellsFargo : Banka
    {
        //Probaj da napravis da bude singleton

        private static WellsFargo instance;
        private List<Kredit> krediti = new List<Kredit>();

        private WellsFargo() { }
        public static WellsFargo Instance
        {
            get { 
                if(instance == null)
                    return new WellsFargo();
                return instance; 
            }
        }

        public override bool proveriZahtev(ZahtevZaKredit zahtev)
        {
            ///Wells Fargo odobrava kredit ukoliko su mesečna primanja klijenta veća od rate kredita.

            if((zahtev.IznosKredita/zahtev.BrojMesecnihRata) < zahtev.PodnosilacZahteva.MesecnaPrimanja )
                return true;
            return false;
        }

        public void odobriKredit(ZahtevZaKredit zahtev) //Dodaje kredit u listu postojecih kredita
        {
            krediti.Add(new Kredit(zahtev.PodnosilacZahteva, "Wells Fargo", zahtev.IznosKredita, zahtev.BrojMesecnihRata));
        }

        public override void podnesiZahtev(ZahtevZaKredit zahtev)
        {
            if (proveriZahtev(zahtev))
                odobriKredit(zahtev);
        }

        public override void dajListingKredita()
        {
            foreach(Kredit kredit in krediti)
                Console.WriteLine(kredit.ToString());
        }

        public override int dajListingKlijenta(string jmbg)
        {
            int i = 0;
            foreach (Kredit kredit in krediti)
            {
                if (kredit.Klijent.Jmbg == jmbg)
                {
                    i++;
                    Console.Write("\n" + i + ".");
                    kredit.ispisiInformacije();
                }
            }

            return i;
        }

        public override int dajListingAktivnihKlijenta(string jmbg)
        {
            int i = 0;
            foreach (Kredit kredit in krediti)
            {
                if (kredit.Klijent.Jmbg == jmbg && kredit.StatusKredita)
                {
                    i++;
                    Console.Write("\n" + i + ".");
                    kredit.ispisiInformacije();
                }
            }

            return i;
        }

        public override void uplatiRatuZaKredit(int redniBrojKredita, string jmbg)
        {
            int i = 1;

            foreach (Kredit kredit in krediti)
            {
                if (kredit.Klijent.Jmbg == jmbg)
                {
                    if (i == redniBrojKredita)
                    {
                        kredit.platiRatu();
                    }
                    else
                        i++;
                }
            }
        }
    }
}
