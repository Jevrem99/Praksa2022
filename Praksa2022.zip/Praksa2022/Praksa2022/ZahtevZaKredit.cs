﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praksa2022
{
    public class ZahtevZaKredit
    {

        //Probaj da proveris da li je uneto dobro ime banke, ako nije probaj da bacis poseban exception da to naznacis

        public string NazivBanke { get; }
        public Klijent PodnosilacZahteva { get; private set; }
        public double IznosKredita { get; }

        public int BrojMesecnihRata { get; }
        private bool Odobreno { get; }  //Verovatno nepotrebno

        public ZahtevZaKredit(string nazivBanke, Klijent podnosilacZahteva, double iznosKredita, int brojMesecnihRata)
        {
            if(proveriNazivBanke(nazivBanke))
            {
                NazivBanke = nazivBanke;
            }
            PodnosilacZahteva=podnosilacZahteva;
            IznosKredita=iznosKredita;
            BrojMesecnihRata=brojMesecnihRata;
            Odobreno=false;
        }

        private bool proveriNazivBanke(string nazivBanke)
        {
            if(nazivBanke.ToLower() == "rbc" || nazivBanke.ToLower() == "santander" || nazivBanke.ToLower() == "wellsfargo" || nazivBanke.ToLower() == "wells fargo")
            {
                return true;
            }

            return false;
        }

    }
}
