﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Praksa2022
{
    public class Program
    {
        static void Main(string[] args)
        {
            RBC rbc = RBC.Instance;
            Santander santander = Santander.Instance;
            WellsFargo wellsFargo = WellsFargo.Instance;

            //Unos podataka

            Console.WriteLine("Uneti putanju do fajla sa zahtevima za kredit: ");
            string putanja = Console.ReadLine();
            List<ZahtevZaKredit> zahtevi = new List<ZahtevZaKredit>();

            using (var reader = new StreamReader(putanja))
            {
                while (!reader.EndOfStream)
                {
                    var red = reader.ReadLine();
                    var vrednosti = red.Split(",");

                    string nazivBanke = vrednosti[0];
                    string imeKlijenta = vrednosti[1];
                    string jmbg = vrednosti[2];
                    double mesecnaPrimanjaKlijenta = double.Parse(vrednosti[3]);
                    double radniStazKlijenta = int.Parse(vrednosti[4]);
                    double iznosKredita = double.Parse(vrednosti[5]);
                    int brojMesecnihRata = int.Parse(vrednosti[6]);


                    zahtevi.Add(new ZahtevZaKredit(nazivBanke, new Klijent(imeKlijenta, jmbg, mesecnaPrimanjaKlijenta, radniStazKlijenta), iznosKredita, brojMesecnihRata));
                }
            }

            Console.WriteLine("Zahtevi za kredite uspesno ucitani.");

            //Izbor opcija

            Console.WriteLine("\nOpcije:\n1-placanje rate\n2-informacije o kreditima\n3-unos novih aplikacija za kredit");
            
            while (true) {

                Console.WriteLine("\nIzaberite opciju: ");
                string imeBanke;
                string jmbgKlijenta;

                int izabranaOpcija = int.Parse(Console.ReadLine());

                if (izabranaOpcija == 1) //Placanje rate
                {
                    Console.WriteLine("Ime banke: ");
                    imeBanke = Console.ReadLine();
                    Console.WriteLine("JMBG klijenta: ");
                    jmbgKlijenta = Console.ReadLine();

                    int brojAktivnihKreditaKlijenta = 0;

                    if (imeBanke.ToLower() == "rbc")
                        brojAktivnihKreditaKlijenta = rbc.dajListingAktivnihKlijenta(jmbgKlijenta);
                    else if (imeBanke.ToLower() == "santander")
                        brojAktivnihKreditaKlijenta = santander.dajListingAktivnihKlijenta(jmbgKlijenta);
                    else if (imeBanke.ToLower() == "wells fargo" || imeBanke.ToLower() == "wellsfargo")
                        brojAktivnihKreditaKlijenta = wellsFargo.dajListingAktivnihKlijenta(jmbgKlijenta);


                    //Izbor kredita za placanje rate
                    if (brojAktivnihKreditaKlijenta > 1)
                    {
                        
                        Console.WriteLine("\nIzabrati kredit za pacanje rate");
                        Console.WriteLine("Uneti redni broj kredita za uplatu rate: ");
                        int redniBrojKredita = int.Parse(Console.ReadLine());
                        if(redniBrojKredita > 1 && redniBrojKredita <= brojAktivnihKreditaKlijenta)
                        {
                            if (imeBanke.ToLower() == "rbc")
                                rbc.uplatiRatuZaKredit(redniBrojKredita, jmbgKlijenta);
                            else if (imeBanke.ToLower() == "santander")
                                santander.uplatiRatuZaKredit(redniBrojKredita, jmbgKlijenta);
                            else if (imeBanke.ToLower() == "wells fargo" || imeBanke.ToLower() == "wellsfargo")
                                wellsFargo.uplatiRatuZaKredit(redniBrojKredita, jmbgKlijenta);

                            Console.WriteLine("Uplacena rata za dati kredit.");
                        }
                    }
                    else if(brojAktivnihKreditaKlijenta == 1)
                    {
                        if (imeBanke.ToLower() == "rbc")
                            rbc.uplatiRatuZaKredit(1, jmbgKlijenta);
                        else if (imeBanke.ToLower() == "santander")
                            santander.uplatiRatuZaKredit(1, jmbgKlijenta);
                        else if (imeBanke.ToLower() == "wells fargo" || imeBanke.ToLower() == "wellsfargo")
                            wellsFargo.uplatiRatuZaKredit(1, jmbgKlijenta);

                        Console.WriteLine("\nUplacena je rata za dati kredit");
                    }
                    else if(brojAktivnihKreditaKlijenta == 0)
                    {
                        Console.WriteLine("Dati klijent nema nijedan kredit u datoj banci");
                    }
                    
                }
                else if (izabranaOpcija == 2)
                {
                    Console.WriteLine("Ime banke: ");
                    imeBanke = Console.ReadLine();
                    Console.WriteLine("JMBG klijenta: ");
                    jmbgKlijenta = Console.ReadLine();

                    if (imeBanke.ToLower() == "rbc")
                        rbc.dajListingKlijenta(jmbgKlijenta);
                    else if (imeBanke.ToLower() == "santander")
                        santander.dajListingKlijenta(jmbgKlijenta);
                    else if (imeBanke.ToLower() == "wells fargo" || imeBanke.ToLower() == "wellsfargo")
                        wellsFargo.dajListingKlijenta(jmbgKlijenta);

                }
                else if (izabranaOpcija == 3) //Unos novih aplikacija
                {
                    Console.WriteLine("Uneti putanju do fajla sa aplikacijama: ");
                    putanja = Console.ReadLine();
                    zahtevi.Clear();

                    using (var reader = new StreamReader(putanja))
                    {
                        while (!reader.EndOfStream)
                        {
                            var red = reader.ReadLine();
                            var vrednosti = red.Split(",");

                            string nazivBanke = vrednosti[0];
                            string imeKlijenta = vrednosti[1];
                            string jmbg = vrednosti[2];
                            double mesecnaPrimanjaKlijenta = double.Parse(vrednosti[3]);
                            double radniStazKlijenta = int.Parse(vrednosti[4]);
                            double iznosKredita = double.Parse(vrednosti[5]);
                            int brojMesecnihRata = int.Parse(vrednosti[6]);


                            zahtevi.Add(new ZahtevZaKredit(nazivBanke, new Klijent(imeKlijenta, jmbg, mesecnaPrimanjaKlijenta, radniStazKlijenta), iznosKredita, brojMesecnihRata));
                        }
                    }
                    Console.WriteLine("Zahtevi za kredite uspesno ucitani.");
                }
                else
                {
                    Console.WriteLine("Nepostojaca opcija! Probajte ponovo");
                }

            }

        }
    }
}
