﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praksa2022
{
    public class Kredit
    {
        //Ovo moram da koristim da bih napravio listu kredita koja je u svakom klijentu da bi banke mogle da dobiju
        // listing kredita za svakog klijenta

        public Klijent Klijent { get; private set; }
        private string ImeBanke { get; }
        public double IznosKredita { get; private set; }

        public int BrojMesecnihRata { get; private set; }
        public bool StatusKredita { get; private set; }  //true - kredit je aktivan(neisplacen); false - kredit je isplacen 

        public double MesecnaRata { get; private set; }
        public double OstaloZaUplatu { get; private set; }
        public int OstaloRata { get; private set; }
        public Kredit(Klijent klijent, string imeBanke, double iznosKredita, int brojMesecnihRata)
        {
            Klijent=klijent;
            ImeBanke=imeBanke;
            IznosKredita=iznosKredita;
            this.BrojMesecnihRata=brojMesecnihRata;
            StatusKredita = true;
            MesecnaRata = IznosKredita / BrojMesecnihRata;
            OstaloZaUplatu = IznosKredita;
            OstaloRata = BrojMesecnihRata;
        }

        public void ugasiKredit()
        {
            this.StatusKredita = false;
        }

        public void platiRatu()
        {
            if (StatusKredita)
            {
                OstaloZaUplatu -= MesecnaRata;
                OstaloRata--;
            }
            else
                Console.WriteLine("\nDati kredit je vec isplacen.");
            if (OstaloZaUplatu == 0)
                ugasiKredit();
        }

        public override string ToString()
        {
            return Klijent.ToString() + " " + ImeBanke + " " + IznosKredita + " " + BrojMesecnihRata + " " + StatusKredita;
        }

        public void ispisiInformacije()
        {
            Console.WriteLine("Klijent " + Klijent.Ime + "(" + Klijent.Jmbg +")");
            Console.WriteLine("Banka: " + ImeBanke);
            Console.WriteLine("Iznos kredita: " + IznosKredita);
            Console.WriteLine("Broj mesecnih rata kredita: " + BrojMesecnihRata);
            Console.WriteLine("Status kredita: " + (StatusKredita ? "neisplacen" : "isplacen"));
            Console.WriteLine("Iznos rate: " + Math.Round(MesecnaRata,3));
            Console.WriteLine("Ostalo rata: " + OstaloRata);
            Console.WriteLine("Ostalo za uplatu: " + OstaloZaUplatu);
        }
    }
}
