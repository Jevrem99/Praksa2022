﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praksa2022
{
    public class Klijent
    {
        public string Ime { get; }
        public string Jmbg { get; }
        public double MesecnaPrimanja { get; private set; }
        public double RadniStaz { get; }  //Radni staz ne mora da bude ceo broj

        public Klijent(string ime, string jmbg, double mesecnaPrimanja, double radniStaz)
        {
            

            if (jmbg.Length == 13 && jmbg.All(char.IsDigit) && ime.All(char.IsLetter))
            {
                Ime=ime;
                Jmbg=jmbg;
                MesecnaPrimanja=mesecnaPrimanja;
                RadniStaz=radniStaz;
            }
            else
                Console.WriteLine("Uneti neispravni podaci");
            
        }

        public override string ToString()
        {
            return Ime + " " + Jmbg + " " + MesecnaPrimanja + " " + RadniStaz;
        }

        public override bool Equals(object obj)
        {
            return obj is Klijent klijent&&
                   Jmbg==klijent.Jmbg;
        }
    }
}
