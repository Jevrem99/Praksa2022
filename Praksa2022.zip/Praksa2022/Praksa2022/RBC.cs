﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praksa2022
{

    //Klase koje su banke mogu da nasledjuju klasu Banka (moze apstraktna)

    public class RBC : Banka
    {

        //Probaj da napravis da bude singleton

        private static RBC instance = null;
        private List<Kredit> krediti = new List<Kredit>();

        private RBC() { }

        public static RBC Instance
        {
            get
            {
                if (instance == null)
                    instance = new RBC();
                
                return instance;
            }
        }

        public override void podnesiZahtev(ZahtevZaKredit zahtev)
        {
            if (proveriZahtev(zahtev))
                odobriKredit(zahtev);
        }

        public override bool proveriZahtev(ZahtevZaKredit zahtev)
        {
            ///RBC odbija kredit ako klijent ima 
            ///neki aktivan(neisplaćen) kredit u RBC-ju, 
            ///ili ukoliko plata nije bar duplo veća od rate

            foreach(Kredit kredit in krediti)
            {
                if(zahtev.PodnosilacZahteva.Equals(kredit.Klijent))
                {
                    if (kredit.StatusKredita == true || kredit.Klijent.MesecnaPrimanja < 2*(kredit.IznosKredita/kredit.BrojMesecnihRata))
                    {
                        return false;
                    }
                        
                }
            }

            //odobriKredit(zahtev);
            return true;
        }

        private void odobriKredit(ZahtevZaKredit zahtev) //Dodaje kredit u listu postojecih kredita
        {
            krediti.Add(new Kredit(zahtev.PodnosilacZahteva, "RBC", zahtev.IznosKredita, zahtev.BrojMesecnihRata));
        }

        public override void dajListingKredita()
        {
            foreach(Kredit kredit in krediti)
            {
                Console.WriteLine(kredit.ToString());
            }
        }

        public override int dajListingKlijenta(string jmbg)
        {
            int i = 0;
            foreach(Kredit kredit in krediti)
            {
                if(kredit.Klijent.Jmbg == jmbg)
                {
                    i++;
                    Console.Write("\n" + i + ".");
                    kredit.ispisiInformacije();
                    
                }
            }

            return i;
        }

        public override int dajListingAktivnihKlijenta(string jmbg)
        {
            int i = 0;
            foreach (Kredit kredit in krediti)
            {
                if (kredit.Klijent.Jmbg == jmbg && kredit.StatusKredita)
                {
                    i++;
                    Console.Write("\n" + i + ".");
                    kredit.ispisiInformacije();

                }
            }

            return i;
        }


        public override void uplatiRatuZaKredit(int redniBrojKredita,string jmbg)
        {
            int i = 1;

            foreach(Kredit kredit in krediti)
            {
                if(kredit.Klijent.Jmbg == jmbg)
                {
                    if (i == redniBrojKredita)
                    {
                        kredit.platiRatu();
                    }
                    else
                        i++;
                }
            }
        }
    }
}
