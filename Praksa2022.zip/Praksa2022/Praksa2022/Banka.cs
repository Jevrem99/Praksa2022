﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praksa2022
{
    public abstract class Banka
    {
        private List<Kredit> krediti;
        public abstract void podnesiZahtev(ZahtevZaKredit zahtev);
        public abstract bool proveriZahtev(ZahtevZaKredit zahtev);
        public abstract void dajListingKredita();
        public abstract int dajListingKlijenta(string jmbg);

        public abstract int dajListingAktivnihKlijenta(string jmbg);
        
        public abstract void uplatiRatuZaKredit(int redniBrojKredita, string jmbg);
    }
}
