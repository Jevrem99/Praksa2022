﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praksa2022
{
    public class Santander : Banka
    {

        //Probaj da napravis da bude singleton
        private static Santander instance;
        private List<Kredit> krediti = new List<Kredit>();

        private Santander() { }
        
        public static Santander Instance
        {
            get
            {
                if (instance == null)
                    return new Santander();
                return instance;
            }
        }

        public override bool proveriZahtev(ZahtevZaKredit zahtev)
        {
            /// Santander odobrava kredit ukoliko klijent ima preko 5 godina radnog staža 
            /// i ukoliko je iznos mesečne rate manji od 70% mesečnog pirmanja klijenta.

            if (zahtev.PodnosilacZahteva.RadniStaz > 5 && (0.7*zahtev.PodnosilacZahteva.MesecnaPrimanja) > (zahtev.IznosKredita/zahtev.BrojMesecnihRata))
                return true;
 
            return false;
        }

        public void odobriKredit(ZahtevZaKredit zahtev) //Dodaje kredit u listu postojecih kredita
        {
            krediti.Add(new Kredit(zahtev.PodnosilacZahteva, "Santander", zahtev.IznosKredita, zahtev.BrojMesecnihRata));
        }

        public override void podnesiZahtev(ZahtevZaKredit zahtev)
        {
            if (proveriZahtev(zahtev))
                odobriKredit(zahtev);
        }

        

        public override void dajListingKredita()
        {
            foreach (Kredit kredit in krediti)
                Console.WriteLine(kredit.ToString());
        }

        public override int dajListingKlijenta(string jmbg)
        {
            int i = 0;
            foreach (Kredit kredit in krediti)
            {
                if (kredit.Klijent.Jmbg == jmbg)
                {
                    i++;
                    Console.Write("\n" + i + ".");
                    kredit.ispisiInformacije();
                }
            }

            return i;
        }

        public override int dajListingAktivnihKlijenta(string jmbg)
        {
            int i = 0;
            foreach (Kredit kredit in krediti)
            {
                if (kredit.Klijent.Jmbg == jmbg && kredit.StatusKredita)
                {
                    i++;
                    Console.Write("\n" + i + ".");
                    kredit.ispisiInformacije();

                }
            }

            return i;
        }

        public override void uplatiRatuZaKredit(int redniBrojKredita, string jmbg)
        {
            int i = 1;

            foreach (Kredit kredit in krediti)
            {
                if (kredit.Klijent.Jmbg == jmbg)
                {
                    if (i == redniBrojKredita)
                    {
                        kredit.platiRatu();
                    }
                    else
                        i++;
                }
            }
        }
    } 
}
